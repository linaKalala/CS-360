package com.example.mobile2app.inventory.tracker;

import android.Manifest;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.os.Bundle;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.app.ActivityCompat;
import androidx.core.content.ContextCompat;
import androidx.fragment.app.FragmentTransaction;

import com.example.mobile2app.R;
import com.example.mobile2app.databinding.ActivityMainBinding;
import com.example.mobile2app.inventory.tracker.interfaces.OnDialogConfirm;
import com.example.mobile2app.inventory.tracker.views.InventoryItemActivity;
import com.example.mobile2app.inventory.tracker.views.fragments.PermissionsFragment;
import com.google.android.material.snackbar.Snackbar;

public class MainActivity extends AppCompatActivity implements OnDialogConfirm {
    ActivityMainBinding binding;
    View view;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        binding = ActivityMainBinding.inflate(getLayoutInflater());
        view = binding.getRoot();
        setContentView(view);

        binding.tvInventoryEmptyDescription.setVisibility(View.VISIBLE);
        setSupportActionBar(binding.toolbar);
        getSupportActionBar().setTitle("Manage Inventory");

        checkPermissions();

        binding.fab.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent = new Intent(MainActivity.this, InventoryItemActivity.class);
                intent.addFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP | Intent.FLAG_ACTIVITY_NEW_TASK);
                startActivity(intent);
            }
        });
    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        getMenuInflater().inflate(R.menu.menu_main, menu);
        return true;
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        int id = item.getItemId();
        if (id == R.id.action_notification) {
            String msg = "You have no notifications";
            showSnack(msg);
            return true;
        }
        return super.onOptionsItemSelected(item);
    }

    private void showSnack(String msg) {
        Snackbar.make(view, msg, Snackbar.LENGTH_LONG).setAction("OK", null).show();
    }

    private void checkPermissions() {
        if (ContextCompat.checkSelfPermission(
                this, Manifest.permission.READ_SMS) ==
                PackageManager.PERMISSION_DENIED) {
            FragmentTransaction fragmentTransaction = getSupportFragmentManager().beginTransaction();
            fragmentTransaction.replace(android.R.id.content, new PermissionsFragment());
            fragmentTransaction.commit();
        }
    }

    @Override
    public void onRequestPermissionsResult(int requestCode, @NonNull String[] permissions, @NonNull int[] grantResults) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults);
        if (grantResults.length > 0 && grantResults[0] == PackageManager.PERMISSION_DENIED) {
            showSnack("You will not receive our promotion messages!");
        }
    }

    @Override
    public void onDialogConfirm() {
        int PERMISSION_READ_SMS_CODE = 101;
        ActivityCompat.requestPermissions(this, new String[]{Manifest.permission.READ_SMS}, PERMISSION_READ_SMS_CODE);
    }
}
